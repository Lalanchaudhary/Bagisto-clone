import React from 'react'

function Game() {
  return (
    <div className='d-flex justify-content-center text-cente  align-center'>
       <div className='text-center foont lh-base mt-5'>
        <h1 data-aos="fade-up-right">The game with our <br/> new additions!</h1>
       </div>
      
    </div>
  )
}

export default Game
